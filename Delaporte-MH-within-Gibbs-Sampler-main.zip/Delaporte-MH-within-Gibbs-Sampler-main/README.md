# Delaporte-MH-within-Gibbs-Sampler
R implementation of a  Metropolis Hastings-within-Gibbs sampler for the Delaporte distribution, with diagnostics, and reproducible examples. Shows Poisson-limit behavior. 
